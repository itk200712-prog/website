Panduwasnuwara New MPCS — FULL SITE BACKUP
Generated: 2026-10-17T08:29:07.463Z

මේ ZIP එකේ තියෙන්නේ:
  • database.sql        — සියලු tables (members, voters, profiles+passwords, chat,
                          system settings, board, news, gallery, messages(live chat),
                          applications, fuel, f28, activity logs, images(base64))
  • Members-Register.xlsx — සියලු සාමාජික විස්තර (52976 පේළි)
  • Voters-Register.xlsx  — සියලු ඡන්ද හිමි විස්තර (52976 පේළි)
  • Members-Register.csv / Voters-Register.csv — UTF-8 CSV

RESTORE කරන විදිහ:
  1) Admin → Backup & Restore → Import (import password එක දෙන්න)
  0) ⚠ FRESH project එකකට restore කරනවා නම්: මුලින්ම supabase/schema.sql
     run කරන්න (tables + RLS policies + live chat functions). ඊට පස්සේ:
  2) හෝ Supabase → SQL Editor → database.sql run කරන්න (data)
  3) ඉන්පසු admin එකේ Backup → Import එකෙන් images storage එකට re-upload වේ

⚠ auth.users passwords Supabase එකෙන් පිටතට export කළ නොහැක (security).
   නමුත් සියලු profiles + password_display (base64) + role/status backup එකේ ඇත.
   Restore එකෙන් පසු අවශ්‍ය නම් password reset කරන්න.